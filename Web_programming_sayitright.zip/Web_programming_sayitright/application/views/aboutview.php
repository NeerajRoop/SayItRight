
<? php include_once('header.php'); ?>
<h5 style=" position: absolute; top: 15%; left: 34.5%; color: white; font-family:arial ">Home &rarr; About</h5>
	<h1 class="hdabt">ABOUT US</h1>

	<div id="abmid">
		<div id="abtxt">
			<h3 id="abh" style="font-size: 15px;"> ABOUT US</h3>
			<h2 id="abh2"> Say it Right</h2>
			<p id="abpar">Is an application for everyone. It is the first step to a good relationship.<br>It is about identity, about the importance of my name, my culture. If<br>
			you want to, I will help you to Say it Right, si that you can address me<br>correctly</p>
		</div>

		<img src="<?php echo base_url('images/about.png'); ?>" id="abimg">

	</div>
<? php include_once('footer.php'); ?>
