<style type="text/css">
	#wrapper{
	width: 80%;
	height: 98%;
	margin-left: auto;
	margin-right: auto;
}
h1{
	line-height: 200%;
	font-family: arial,verdana;
}
h2{
	font-family: georgia,serif;
}
.nv{
	width: 80%;
	background: #191970;
	padding-top: 20px;
	padding-bottom: 20px;
	height: 30px;
}
.nva{
	color: white;
	padding-right: 2%;
	padding-left: 2%;
	font-size: 60%;
	font-weight: bold;
	text-decoration: none;
	font-family: arial, serif;
}
.nvaa{
	float: right;
	width: 75%;
	position: relative;
	top: 50%;
	left: 7%;
	padding-top: 10px;
}
.icn{
	position: absolute;
	top: 15px;
	left: 10%;
	width: 90px;
	height: 50px;
}

#dark{
	position: absolute;
	top: 50%;
	left: 0%;
	background: white;
	width: 80%;
	height: 170%;
}
.bgimg{
	position: relative;
	width: 80%;
	height: 100%;
}

.bgmg{
	position: relative;
	width: 80%;
	height: 50%;
}
.txt{
	position: absolute;
	top:20%;
	left: 45%;
	color: white;
	font-family: arial;
	font-weight: bold;
	font-size: 30px;
}

.txtwv{
	position: absolute;
	top:63%;
	left: 49%;
	color: white;
	font-family: arial;
	font-weight: bold;
	font-size: 10px;
}

#txtwicon{
	position: absolute;
	top:63%;
	left: 45%;
	font-size: 30px;
	color: #00bfff;
}
#smtx{
	font-size: 8px;
}

.sub{
	width: 80%;
	height: 20%;
	position: absolute;
	top:90%;
	left: 0%;
	background-image: linear-gradient(to right, #00bfff , #98fb98);
}

.sub1{
	width: 80%;
	height: 25%;
	position: absolute;
	top:190%;
	left: 0%;
	background-image: linear-gradient(to right, #00bfff , #98fb98);
}
.hdabt{
	position: absolute;
	top: 19%;
	left: 32%;
	color: white;
	font-family: arial;
}
.hdbt{
	position: absolute;
	top: 19%;
	left: 36%;
	line-height: 200%;
	color: white;
	font-family: arial;
	margin-bottom: 15px;
}
.hdbta{
	position: absolute;
	top: 19%;
	left: 34%;
	line-height: 200%;
	color: white;
	font-family: arial;
	margin-bottom: 15px;
}

.hdbt1{
	position: absolute;
	top: 19%;
	left: 31%;
	line-height: 200%;
	color: white;
	font-family: arial;
	margin-bottom: 15px;
}

#lgbtn{
	position: absolute;
	top:120%;
	left:35%;
	border: none;
	background-image: linear-gradient(to right, #00bfff , #98fb98);
	padding: 10px;
	padding-left: 15px;
	padding-right: 15px;
	border-radius: 10%;
	color: #191970;
	font-size: 12px;
	font-weight: bold;
}

#spbtn{
	position: absolute;
	top:97%;
	left:35%;
	border: none;
	background-image: linear-gradient(to right, #00bfff , #98fb98);
	padding: 10px;
	padding-left: 15px;
	padding-right: 15px;
	border-radius: 10%;
	color: #191970;
	font-size: 12px;
	font-weight: bold;
}

#setbtn{
	margin-left: 2%;
	position: absolute;
	top:105%;
	left:22%;
	border: none;
	background-image: linear-gradient(to right, #00bfff , #98fb98);
	padding: 10px;
	padding-left: 15px;
	padding-right: 15px;
	border-radius: 7%;
	color: #191970;
	font-size: 12px;
	font-weight: bold;
}

#spbtnn{
	margin-top: 10px;
	margin-left: 7px;
	border: none;
	background-image: linear-gradient(to right, #00bfff , #98fb98);
	padding: 10px;
	padding-left: 15px;
	padding-right: 15px;
	border-radius: 5%;
	color: #191970;
	font-size: 12px;
	font-weight: bold;
}

#wrapper{
	width: 100%;
	position: absolute;
	margin-left: 10%;
	top: 0%;
}
#spbtnn1{
	margin-top: 10px;
	border: none;
	background-image: linear-gradient(to right, #00bfff , #98fb98);
	padding: 8px;
	padding-left: 15px;
	padding-right: 15px;
	border-radius: 5%;
	color: #191970;
	font-size: 9px;
	font-weight: bold;
}


.lgin{
	position: absolute;
	top:30%;
	left: 30%;
	width: 100%;

}
.temp{
	position: absolute;
	top:20%;
	left:25%;
	width: 50%;
	height: 50%;
	box-shadow:0px 5px 5px 5px lightgrey;
}

.temp1{
	position: absolute;
	top:18%;
	left:23%;
	width: 50%;
	height: 30%;
	box-shadow: 0px 5px 5px 5px lightgrey;
}

.temp2{
	position: absolute;
	top:2%;
	left:26%;
	width: 45%;
	height: 107%;
	box-shadow: 0px 5px 5px 5px lightgrey;
}

.temp3{
	position: absolute;
	top:20%;
	left:17%;
	width: 45%;
	height: 70%;
	box-shadow: 0px 5px 5px 5px lightgrey;
}

.temp4{
	position: absolute;
	background: white;
	z-index: 15;
	top:95%;
	left:21%;
	filter: brightness(100%);
	width: 35%;
	height: 55%;
	border: 1px solid lightgrey;
}

.temp5{
	position: absolute;
	top:35%;
	left:5%;
	width: 70%;
	height: 80%;
	box-shadow: 0px 5px 5px 5px lightgrey;
}

.hcon{
	position: absolute;
	top: 25%;
	left: 26%;
	color: #191970;
	font-family: arial;
}

.hcon1{
	position: absolute;
	top: 12%;
	left: 28%;
	color: #191970;
	font-family: arial;
}
#abmid{
	width: 80%;
	height: 70%;
	position: absolute;
	top:45%;
	z-index: 10;
	left: 0%;
	background: white;
}

#abtxt{
	width: 55%;
	height: 55%;
	color: white;
	background-image: radial-gradient(#483d8b, #191970,#191970);
	position: absolute;
	font-family: verdana;
	top: 15%;
	left: 13%;
	padding: 30px;
	padding-left: 70px;
}
#abpar{
	font-size: 9px;
	padding: 7px;
	margin-bottom: 10px;
	line-height: 15px;
}

#abimg{
	position: absolute;
	top: 20%;
	left:53%;
	width: 35%;
	height: 60%;
}
#parr{
	position: relative;
	font-family: arial;
	font-size: 20px;
	margin-bottom: 5px;
	font-weight: bold;
	color: #191970;
}

#parrr{
	position: relative;
	top: 50%;
	font-family: arial;
	font-size: 8px;
	font-weight: bold;
	color: gray;
}

#pa{
	position: relative;
	top: 20px;
	margin-left: 15%;
	margin-bottom: 30px;

}

#form{
	position: absolute;
	top:30%;
	right:15%;
	float: right;
	background: white;
	padding: 5px;
	padding-right: 0px;
	border-radius: 35px;
	width: 30%;
	padding-left: 10px;
}
#form1{
	position: absolute;
	top:25%;
	left: 70%;
	background: white;
	padding: 5px;
	padding-left: 0px;
	border-radius: 35px;
	width: 10%;
	padding-left: 10px;
}
#a{
	border: none;
	width:62%;
	margin-left: 5%;
}
#b{
	position: relative;
	left:15px;
	color: #191970;
	font-weight: bold;
	font-family: arial;
	width: 25%;
	font-size: 9px;
	border:none;
	margin-right: 1px;
	border-radius: 15px;
	padding: 10px;
	background-image: linear-gradient(to right, #00bfff , #98fb98);
}

#b1{
	position: relative;
	margin-left: 0%;
	color: #191970;
	font-weight: bold;
	font-family: arial;
	width: 100%;
	font-size: 9px;
	border:none;
	border-radius: 15px;
	padding: 10px;
	background-image: linear-gradient(to right, #00bfff , #98fb98);
}

.foot{
	position: absolute;
	top:110%;
	width: 80%;
	height:20%;
	background-image: radial-gradient(#483d8b, #191970,#191970);
	border-width: 2px; border-top-color: rgb(160,160,255);
}

.foot1{
	position: absolute;
	top:130%;
	width: 80%;
	height:20%;
	background-image: radial-gradient(#483d8b, #191970,#191970);
	border-width: 2px; border-top-color: rgb(160,160,255);
}

.foot2{
	position: absolute;
	top:212%;
	width: 80%;
	height:20%;
	background-image: radial-gradient(#483d8b, #191970,#191970);
	border-width: 2px; border-top-color: rgb(160,160,255);
}


footer{
	position: absolute;
	top: 75%;
	font-size: .70em;
	font-family: roboto;
	align-content: center;
	color: white;
	margin-left: 15%;
}

.cntx{
	width: 40%;
	padding: 5px;
	margin: 5px;
	margin-left: 0px;
	border: 1px solid lightgrey;
}
#lftcnt{
	position: absolute;
	top: 25%;
	left: 12%;
	width: 85%;
}

#cntarea{
	position: absolute;
	top: 25%;
	left: 50%;
	margin: 5px;
	width: 35%;
	height: 28%;
	border: 1px solid lightgrey;
}
#cntbtn{
	position: absolute;
	top: 62%;
	left: 75%;
	padding: 10px;
	font-size: 10px;
	color: #191970;
	background-image: linear-gradient(to right, #00bfff , #98fb98);
	border-radius: 15%;
	border: none;
}
.tbl{
	border-collapse: collapse;
	border: 1px solid lightgrey;
	position: absolute;
	top: 53%;
	left: 7%;
	font-size:78%;
	padding-right: 10px;
	color: grey;
}
.ctd1{
	padding-right: 33px;
	padding-bottom: 10px;
}
.ctd{
	padding: 5px;
	border: 1px solid lightgrey;
	padding-right: 20px;
	padding-bottom: 20px;
}

.lbt{
	border-radius: 5px;
	padding: 10px;
	background-image: linear-gradient(to right, #00bfff , #98fb98);
	font-size: 10px;
	color: #191970;
	font-weight: bold;
	margin-left: 20px;
	margin-right: 20px;
	margin-bottom: 5px;
	border: none;
}

.lbt1{
	border-radius: 5px;
	padding: 10px;
	background-image: linear-gradient(to right, #00bfff , #98fb98);
	font-size: 10px;
	color: #191970;
	font-weight: bold;
	margin-left: 27px;
	margin-right: 20px;
	margin-bottom: 2px;
	border: none;
}

.sgnup{
	width: 80%;
	position: absolute;
	top: 10%;
	left: 30%;
	padding: 20px;
}

.sgnup1{
	width: 100%;
	position: absolute;
	top: 0%;
	left: 30%;
	padding: 15px;
}
#sp{
	margin-left: 5%;
}

#bsn{
	margin-left: 3%;
	color: grey;
	font-size: 12px;
	font-family: arial;
	margin-bottom: 10px;
}

#stlft{
	float: left;
	width: 35%;
	padding: 5%;
}

#strgt{
	position: absolute;
	top: 15%;
	left: 40%;
	margin-top: 5%;
	width: 120%;
}

#stimg{
	margin-top: 10%;
	width: 70%;
	height: 30%;
	margin-right: 10%;
	border-radius: 40%;
}
#n{
	margin-bottom: 4px;
}
#nl{
	position: absolute;
	top: 0%;
	left: 22%;
}
#line{
	position: absolute;
	top:10%;
	left: 10%;
}

#li1{
	position: absolute;
	top:32%;
	left: 13%;
}

#chpwd{
	position: absolute;
	top:67%;
	left: 39%;
	font-size: 12px;
	font-family: arial;

}

.crtimg{
	width: 90%;
	height: 45%;
	padding: 5%;
}

.crtcs{
	font-family: arial;
	font-size: 11px;
	color: grey;
}

.crtcs1{
	font-family: arial;
	font-size: 10px;
	line-height: 170%;
	color: grey;
}
#crdiv1{
	position: absolute;
	top: 35%;
	left: 14%;
	width: 18%;
	height: 75%;
	border: 1px solid lightgrey;
	padding-left: 1%;
}

#crdiv2{
	position: absolute;
	top: 35%;
	left: 39%;
	width: 18%;
	height: 75%;
	border: 1px solid lightgrey;
	padding-left: 1%;
}

#crdiv3{
	position: absolute;
	top: 35%;
	left: 64%;
	width: 18%;
	height: 75%;
	border: 1px solid lightgrey;
	padding-left: 1%;
}

#crdiv4{
	position: absolute;
	top: 115%;
	left: 14%;
	width: 18%;
	height: 75%;
	border: 1px solid lightgrey;
	padding-left: 1%;
}

#crdiv5{
	position: absolute;
	top: 115%;
	left: 39%;
	width: 18%;
	height: 75%;
	border: 1px solid lightgrey;
	padding-left: 1%;
}

#crdiv6{
	position: absolute;
	top: 115%;
	left: 64%;
	width: 18%;
	height: 75%;
	border: 1px solid lightgrey;
	padding-left: 1%;
}
.by{
	position: absolute;
	top:8%;
	left: 40%;
	color: #191970;
}

.hmtb{
	position: absolute;
	top: 52%;
	left: 6%;
	color: white;
	width: 13%;
	height: 23%;
	font-family: arial;
	padding:1%;
	padding-left: 1%;
	border-radius: 3%;
	border:1px solid lightgrey;
}
.hmtb2{
	position: absolute;
	top: 52%;
	left: 23%;
	color: white;
	width: 13%;
	height: 23%;
	font-family: arial;
	padding:1%;
	padding-left: 1%;
	border-radius: 3%;
	border:1px solid lightgrey;
}
.hmtb3{
	position: absolute;
	top: 52%;
	left: 40%;
	color: white;
	width: 13%;
	height: 23%;
	font-family: arial;
	padding:1%;
	padding-left: 1%;
	border-radius: 3%;
	border:1px solid lightgrey;
}
.hmtb4{
	position: absolute;
	top: 52%;
	left: 57%;
	color: white;
	width: 13%;
	height: 23%;
	font-family: arial;
	padding:1%;
	padding-left: 1%;
	border-radius: 3%;
	border:1px solid lightgrey;
}
.hmtb5{
	position: absolute;
	top: 85%;
	left: 6%;
	color: white;
	width: 13%;
	height: 23%;
	font-family: arial;
	padding:1%;
	padding-left: 1%;
	border-radius: 3%;
	border:1px solid lightgrey;
}
.hmtb6{
	position: absolute;
	top: 85%;
	left: 23%;
	color: white;
	width: 13%;
	height: 23%;
	font-family: arial;
	padding:1%;
	padding-left: 1%;
	border-radius: 3%;
	border:1px solid lightgrey;
}
.hmtb7{
	position: absolute;
	top: 85%;
	left: 40%;
	color: white;
	width: 13%;
	height: 23%;
	font-family: arial;
	padding:1%;
	padding-left: 1%;
	border-radius: 3%;
	border:1px solid lightgrey;
}
.hmtb8{
	position: absolute;
	top: 85%;
	left: 57%;
	color: white;
	width: 13%;
	height: 23%;
	font-family: arial;
	padding:1%;
	padding-left: 1%;
	border-radius: 3%;
	border:1px solid lightgrey;
}
.hmth{
	margin-top: 0%;
	padding-top: 5%;
	position: absolute;
	top: 0%;
	left: 0%;
	width: 90%;
	height: 12%;
	font-size: 9px;
	padding: 5%;
	font-weight: bold;
	border-radius: 3%;
}
.hmtp{
	font-size:9px;
	font-weight: bold;
	margin-bottom: 5%;
}
.hmtp2{
	font-size: 60%;
	line-height: 170%;

}

.ggg{
	position: absolute;
	top: 28%;
}

.tpbx{
	position: absolute;
	top: 20%;
	left: 6%;
	width: 13%;
	height: 18%;
	font-family: arial;
	padding:1%;
	padding-left: 1%;
	border-radius: 1%;
	border:1px solid lightgrey;
}

.tpbx1{
	position: absolute;
	top: 20%;
	left: 23%;
	width: 13%;
	height: 18%;
	font-family: arial;
	padding:1%;
	padding-left: 1%;
	border-radius: 1%;
	border:1px solid lightgrey;
}
.tpbx2{
	position: absolute;
	top: 20%;
	left: 40%;
	width: 13%;
	height: 18%;
	font-family: arial;
	padding:1%;
	padding-left: 1%;
	border-radius: 1%;
	border:1px solid lightgrey;
}

.tpbx3{
	position: absolute;
	top: 20%;
	left: 57%;
	width: 13%;
	height: 18%;
	font-family: arial;
	padding:1%;
	padding-left: 1%;
	border-radius: 1%;
	border:1px solid lightgrey;
}

.tp{
	color: white;
	position: absolute;
	top: 0%;
	left: 0%;
	width: 100%;
	height: 75%;
}
#tpic{
	position: absolute;
	top: 22%;
	left: 10%;
	font-size: 300%;
}
#tpnm{
	position: absolute;
	top: 2%;
	left: 76%;
	font-size: 20px;
	font-weight: bold;
	font-family: agency FB;
}
#tptx{
	position: absolute;
	top: 55%;
	left: 37%;
	font-family: arial;
	font-size: 9px;
	font-weight: bold;
}
.btm{
	position: absolute;
	top:75%;
	left: 60%;
	font-size: 10px;
	font-family: arial;
	color: grey;
}

#byimg1{
	position: absolute;
	top:25%;
	left: 3%;
	width: 40%;
	height: 55%;

}
.byrgt{
	position: absolute;
	top: 15%;
	left: 40%;
}

.hmth10{
	position: absolute;
	top: 0%;
	width: 100%;
	height: 16%;
	color: grey;
	font-family: grey;
	font-size: 14px;
	font-weight: bold;
}

#tprr{
	position: absolute;
	top: 0%;
	left: 92%;
	font-family: arial;
	font-size: 16px;
}

#rttx{
	color: #6b6b6b; 
	font-family: arial;
	font-size: 13px; 
	margin-top: 10%;
	font-weight: bold;
}

#rttxbx{
	margin-left: 7%;
	height: 55%;
	width: 70%;
	padding-bottom: 3%;
}

.byrp2{
	color: #ad4848;
	font-size: 12px;
	font-family: arial;
	line-height: 150%;
	margin-top: 9%;
}

#bybtn{
	position: absolute;
	top: 117%;
	width: 100%;
	left: 38%;
	margin-left: 6%;
}
#btnby1{
	padding: 3%;
	color: white;
	font-family: arial;
	border-radius: 8%;
	border:none;
}
#b2tl{
	position: absolute;
	top: 2%;
	left: 3%;
	color: #6b6b6b;
}

#strgt1{
	position: absolute;
	top: 38%;
	left: 3%;
	width: 100%;
}

#spad{
	position: absolute;
	top: 23%;
	left: 3%;
	color: #6b6b6b;
}
#pstl{
	position: absolute;
	top: 87%;
	left: 22%;
}

#pstllft{
	position: absolute;
	top: 90%;
	left: 0%;
	padding: 0.5%;
	color: grey;
	border: 1px solid lightgrey;
}
#tblimg{
	width: 90px;
	height: 80px;
}
#buy2left{
	position: absolute;
	top: 9%;
	font-size: 13px;
	left: 53%;
	width: 100%;
	color: grey;
	font-family: arial;
}

#tblend{
	border-top:1px solid lightgrey; 
	position: absolute;
	width: 45%;
	top:100%;
}
</style>