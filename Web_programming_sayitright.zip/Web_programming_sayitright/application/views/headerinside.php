<!doctype html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="sayitright.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
</head>

<body id="wrapper">
	<div id="home">
	<nav class="nv">
		<div id=nv>

		<img src="<?php echo base_url('images/sayiticon.png'); ?>" class="icn">
		<div class="nvaa">
		<a href="<?php echo site_url('Homecontroller/homeinsideopen'); ?>" class="nva">HOME</a>
		<a href="<?php echo site_url('Homecontroller/conferenceopen'); ?>" class="nva">CONFERENCES</a>
		<a href="<?php echo site_url('Homecontroller/eventopen'); ?>" class="nva">EVENTS</a>
		<a href="<?php echo site_url('Homecontroller/myconferenceopen'); ?>" class="nva">MY CONFERENCES</a>
		<a href="<?php echo site_url('Homecontroller/myeventopen'); ?>" class="nva">MY EVENTS</a>
		<a href="<?php echo site_url('Homecontroller/settingsopen'); ?>" class="nva">SETTINGS</a>
	</div>
	</div>
	</nav>
	<img src="<?php echo base_url('images/blank.jpg'); ?>" class="bgmg">