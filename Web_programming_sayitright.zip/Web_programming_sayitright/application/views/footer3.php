<div class="foot1">
		<div id="li1"><p style="color:lightgrey;opacity: 0.3;">__________________________________________________________________________________<p></div>
	<footer>Copyright &copy2019 All rights reserved | This web is made with &hearts; by <strong style="color:#00bfff">DiazApps</strong> </footer>
</div>
</body>
</html>