<? php include_once('header.php'); ?>
<h5 style=" position: absolute; top: 15%; left: 34.7%; color: white; font-family:arial ">Home &rarr; Sign Up</h5>
	<h1 class="hdbta">SIGN UP</h1>
	<div id="abmid">
		<div class="temp2"></div>
		<div class="sgnup1">
			<?php echo  validation_errors(); ?>
			<form onsubmit="return example()" method="POST" action="<?php echo site_url('Homecontroller/signup1v'); ?>">
				<h2 id="sp" style="color: grey">Select the type of user</h2>
				<input type="button" name="individual" value="INDIVIDUAL" class="lbt1" onclick="location.href='<?php echo site_url('Homecontroller/signup1open'); ?>'">
				<input type="button" name="event" value="EVENT" class="lbt1" onclick="location.href='<?php echo site_url('Homecontroller/signup2open'); ?>'">
				<input type="button" name="business" value="BUSINESS" class="lbt1" onclick="location.href='<?php echo site_url('Homecontroller/signup3open'); ?>'">

				<p style="color: grey;font-family: arial; font-size: 12px;margin-left: 8%">Welcome to individual registration</p>
				<input type="text" name="nme" placeholder="Enter your name" class="cntx" style="width: 33%" id="contactfname"><br>
				<input type="text" name="lnme" placeholder="Enter last name" class="cntx" style="width: 33%" id="contactlname"> <br>
				<input type="text" name="work" placeholder="Enter place work" class="cntx"
				style="width: 33%" id="contactphone"><br>
				<input type="text" name="school" placeholder="Enter school" class="cntx" style="width: 33%" id="contactareat" ><br>
				<input type="email" name="email" placeholder="Enter email" class="cntx" style="width: 33%" required><br>
				<input type="password" name="pwd" placeholder="Enter password" class="cntx" style="width: 33%" minlength="6" required><br>
				<input type="submit" name="send" value="SEND" id="spbtn" style="top: 100%; left: 29%" >

			</form>
		</div>
	</div>
<? php include_once('footer.php'); ?>
