<?php
	$_SESSION['message'] = "Select the type of user";
	$mysqli= new mysqli('localhost','root','','sayitright1') or die("unable to connect");
	if($_SERVER['REQUEST_METHOD']== 'POST'){
		$conf1 = $_POST['deleteform'];
		$sql = "SELECT * FROM eventadd WHERE conference='$conf1'";
		$res= $mysqli->query($sql);
		while ($row = $res->fetch_assoc()){
		$conf = $row['conference'];
		$desc = $row['description'];
		$date = $row['date'];
		$sede = $row['sede'];
		$sess = $_SESSION['email'];
		$sql1 = "INSERT INTO eventadd1 VALUES('$conf','$desc','$date', '$sede','$sess')";
				if($mysqli->query($sql1)===true){
					$this->load->view('headerinside');
					$this->load->view('styling');
					$this->load->view('home1view');
					$this->load->view('footer3');

				}
				else{
					echo "Not added";
				}

	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>delete</title>
	<script type="text/javascript" src="validation.js"></script>
</head>
<body>
	<p>Enter the name of the event that you want to add:</p>
	<form onsubmit="return example3()" method="POST">
		<input type="text" name="deleteform" placeholder="Enter conference name" id="deletetxt"><br>
		<input type="submit" name="submit" value="ADD" >
	</form>
</body>
</html>