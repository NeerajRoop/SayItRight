<? php include_once('header.php'); ?>
<h5 style=" position: absolute; top: 15%; left: 34%; color: white; font-family:arial ">Home &rarr; Buy From Us</h5>
	<h1 class="hdbt1">BUY FROM US</h1>
	<div id="abmid">
		<h2 class="by">BUY FROM US</h2>
		<div id="crdiv1">
			<img src="<?php echo base_url('images/franela1.jpg'); ?>" class="crtimg">
			<p class="crtcs">$24.99</p>
			<p class="crtcs1">some quick example text to buid on<br>the card title and make up the bulk of<br>the card's content</p>
			<input type="button" name="cart" value="ADD TO CART" id="spbtnn1" onclick="location.href='<?php echo site_url('Homecontroller/buy1open')  ?>'">
		</div>
		<div id="crdiv2">
			<img src="<?php echo base_url('images/taza1.png'); ?>" class="crtimg">
			<p class="crtcs">$24.99</p>
			<p class="crtcs1">some quick example text to buid on<br>the card title and make up the bulk of<br>the card's content</p>
			<input type="button" name="cart" value="ADD TO CART" id="spbtnn1" onclick="location.href='<?php echo site_url('Homecontroller/buy5open')  ?>'">
		</div>

		<div id="crdiv3">
			<img src="<?php echo base_url('images/franela2.jpg'); ?>" class="crtimg">
			<p class="crtcs">$24.99</p>
			<p class="crtcs1">some quick example text to buid on<br>the card title and make up the bulk of<br>the card's content</p>
			<input type="button" name="cart" value="ADD TO CART" id="spbtnn1" onclick="location.href='<?php echo site_url('Homecontroller/buy3open')  ?>'">
		</div>
		<div id="crdiv4">
			<img src="<?php echo base_url('images/taza2.png'); ?>" class="crtimg">
			<p class="crtcs">$24.99</p>
			<p class="crtcs1">some quick example text to buid on<br>the card title and make up the bulk of<br>the card's content</p>
			<input type="button" name="cart" value="ADD TO CART" id="spbtnn1" onclick="location.href='<?php echo site_url('Homecontroller/buy6open')  ?>'">
		</div>
		<div id="crdiv5">
			<img src="<?php echo base_url('images/franela3.jpg'); ?>" class="crtimg">
			<p class="crtcs">$24.99</p>
			<p class="crtcs1">some quick example text to buid on<br>the card title and make up the bulk of<br>the card's content</p>
			<input type="button" name="cart" value="ADD TO CART" id="spbtnn1" onclick="location.href='<?php echo site_url('Homecontroller/buy4open')  ?>'">
		</div>

		<div id="crdiv6">
			<img src="<?php echo base_url('images/taza3.png'); ?>" class="crtimg">
			<p class="crtcs">$24.99</p>
			<p class="crtcs1">some quick example text to buid on<br>the card title and make up the bulk of<br>the card's content</p>
			<input type="button" name="cart" value="ADD TO CART" id="spbtnn1" onclick="location.href='<?php echo site_url('Homecontroller/buy7open')  ?>'">
		</div>

		</div>
		<div class="sub1">
		<div id="pa">
		<p id="parr"><strong>View shopping cart</strong></p>
		<p id="parrr">You can see the products that you added to your cart</p>
	</div>
		<form id="form1">
			<div>
			<input type="button" value="SUBMIT" id="b1" onclick="location.href='<?php echo site_url('Homecontroller/buy2open'); ?>'">
			</div>
		</form>
	</div>

<? php include_once('footer2.php'); ?>