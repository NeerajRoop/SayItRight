<? php include_once('header.php'); ?>
<div class="txt">
	<p>For good<br>communication<br><strong style="color:red">Say it Right</strong> is<br>a tool that<br>you should use<br> <p id="smtx">You can see our video tutorial of use with just pressing this<br>button  </p></p>
	</div>
		<i class="fas fa-play-circle" id="txtwicon"></i>
		<p style="color: white; " class="txtwv">WATCH THE VIDEO</p>
	<div class="sub">
		<div id="pa">
		<p id="parr"><strong>Subscribe Our Newsletter</strong></p>
		<p id="parrr">We won't send any kind of spam</p>
	</div>
		<form onsubmit="return example3()" id="form" method="POST">
			<div>
			<input type="text" name="email" placeholder="Enter email address" id="a" required >
			<input type="submit" name="Subscribe" value="SUBSCRIBE" id="b">
			</div>
		</form>
	</div>
	<div class ="emp"> </div>
<? php include_once('footer.php'); ?>
