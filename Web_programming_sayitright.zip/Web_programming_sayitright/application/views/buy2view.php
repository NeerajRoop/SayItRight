<? php include_once('header2.php'); ?>
<h1 class="hcon1" style="margin-left: 3%">Buy From Us</h1>
	<div class ="temp5">
	<div id="b2tl">
		<?php echo validation_errors(); ?>
		<form onsubmit="return example()" method="POST" action="<?php echo site_url('Homecontroller/buy2v'); ?>">
		<h2 style="margin-bottom: 3%;"> Contact information</h2>
		<input type="email" name="eml" placeholder="Enter Email" class="cntx" style="width: 148%" required>
	</div>
		<h2 id="spad"> Shipping address</h2>
	<div id="strgt1">
			<div id="n">
			<input type="text" name="nme" placeholder="Enter your name" class="cntx" style="float: left; width: 18%;" id="contactfname"><br>
			<input type="text" name="lnme" placeholder="Enter last name" class="cntx" style="float: right; width: 18%;" id="nl" id="contactlname"><br>
		</div>
			<input type="text" name="work" placeholder="Enter Address" class="cntx"  id="contactareat"><br>
			<input type="text" name="school" placeholder="Enter Apartment,suite,etc." class="cntx"  id="contactareat"><br>
			<input type="text" name="email" placeholder="Enter City" class="cntx"  id="contactareat"><br>
		<div id="n" style="width: 100% margin-bottom:3%">
			<select style="float: left; width: 18%;" name="lang" id="pstllft" required>
				<option value="English">English</option>
				<option value="Tamil">Tamil</option>
				<option value="Hindi">Hindi</option>
			</select>
			<input type="text" name="lnmess" placeholder="Enter Postal Code" class="cntx" style="float: right; width: 18%;" id="pstl" pattern="\d{5}" required><br>
		</div>
			<input type="submit" name="send" value="SEND MESSAGE" id="setbtn" style="margin-left: 4%; margin-top: 2%;">
		

	</div>
</form>
	<div id="buy2left">
		<table>
			<tr>
				<th class ="ctd1">ID</th>
				<th class="ctd1">Units</th>
				<th class="ctd1">Name</th>
				<th class="ctd1">Price</th>
			</tr>
			<?php

		$_SESSION['message'] = "";
		$mysqli= new mysqli('localhost','root','','sayitright1') or die("unable to connect");
	
		$sql = "SELECT * FROM cart";
		$res= $mysqli->query($sql);
		$i=0;
		while ($row = $res->fetch_assoc()){

			?>
			<tr>
				<td class="ctd1"><img src="<?php echo base_url(); ?>images/<?php echo $row['ID']; ?>"  id="tblimg"></td>
				<td class="ctd1"><?= $row['units'] ?></td>
				<td class="ctd1"><?= $row['name'] ?></td>
				<td class="ctd1"><?= $row['price'] ?></td>
			</tr>
			<?php
			$i = $i+$row['price'];
	}
	?>
		</table>
		<table id="tblend">
			<tr class="ctd1" style="padding-top: 10px">
				<td class="ctd1" style="padding-top: 15px; padding-left: 8% "> <strong>Total </strong></td>
				<td class="ctd1" style="padding-top: 15px ; padding-left: 17%;" >USD</td>
				<td class="ctd1" style="padding-top: 15px; padding-left: 5%;">$ <?= $i ?></td>
			</tr>
		</table>
	</div>

</div>
<? php include_once('footer2.php'); ?>