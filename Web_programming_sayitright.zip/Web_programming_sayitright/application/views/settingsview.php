
<? php include_once('headerinside.php'); ?>
<div class="temp3">
		<p id="chpwd">Change Password</p>
		<p style="color: grey; font-size: 13px; font-family: arial; margin-top: 5%;margin-left: 37%"><strong>Welcome to your profile</strong></p>
		<div id="line"><p style="color:lightgrey ">_________________________________________________________________<p></div>
		<div id="stlft">
		<img src="<?php echo base_url('images/user.jpg'); ?>" id="stimg">
		<input type="button" name="imgchange" value="CHANGE IMAGE" id="spbtnn">
	</div>
	<div id="strgt">
		<div id="n">
			<form method="POST">
			<input type="text" name="nme" placeholder="Enter your name" value="<?= $_SESSION['fname'] ?>" class="cntx" style="float: left; width: 18%;"><br>
			<input type="text" name="lnme" placeholder="Enter last name" value="<?= $_SESSION['lname'] ?>" class="cntx" style="float: right; width: 18%;" id="nl"><br>
		</div>
			<input type="text" name="work" placeholder="Enter place work" value="<?= $_SESSION['work'] ?>" class="cntx"><br>
			<input type="text" name="school" placeholder="Enter school" value="<?= $_SESSION['school'] ?>" class="cntx"><br>
			<input type="email" name="email" placeholder="Enter email" value="<?= $_SESSION['email'] ?>" class="cntx"><br>
			<input type="text" name="pwd" placeholder="Enter password" value="<?= $_SESSION['pass'] ?>" class="cntx"><b>
			<input type="button" name="send" value="SAVE CHANGES" id="setbtn">
			</form>

	</div>
	</div>


<? php include_once('footer.php'); ?>