<? php include_once('header.php'); ?>
<h5 style=" position: absolute; top: 15%; left: 34%; color: white; font-family:arial ">Home &rarr; Buy From Us</h5>
	<h1 class="hdbt1">BUY FROM US</h1>
	<div id="abmid">
		<h2 class="by">BUY FROM US</h2>
		<div id="crdiv1">
			<img src="<?php echo base_url('images/franela1.jpg'); ?>" class="crtimg">
			<p class="crtcs">$24.99</p>
			<p class="crtcs1">some quick example text to buid on<br>the card title and make up the bulk of<br>the card's content</p>
			<input type="button" name="cart" value="ADD TO CART" id="spbtnn1" onclick="location.href='<?php echo site_url('Homecontroller/buy1open')  ?>'">
		</div>
		<div id="crdiv2">
			<img src="<?php echo base_url('images/taza1.png'); ?>" class="crtimg">
			<p class="crtcs">$24.99</p>
			<p class="crtcs1">some quick example text to buid on<br>the card title and make up the bulk of<br>the card's content</p>
			<input type="button" name="cart" value="ADD TO CART" id="spbtnn1" onclick="location.href='buy5.php'">
		</div>

		<div id="crdiv3">
			<img src="<?php echo base_url('images/franela2.jpg'); ?>" class="crtimg">
			<p class="crtcs">$24.99</p>
			<p class="crtcs1">some quick example text to buid on<br>the card title and make up the bulk of<br>the card's content</p>
			<input type="button" name="cart" value="ADD TO CART" id="spbtnn1" onclick="location.href='buy3.php'">
		</div>
		<div id="crdiv4">
			<img src="<?php echo base_url('images/taza2.png'); ?>" class="crtimg">
			<p class="crtcs">$24.99</p>
			<p class="crtcs1">some quick example text to buid on<br>the card title and make up the bulk of<br>the card's content</p>
			<input type="button" name="cart" value="ADD TO CART" id="spbtnn1" onclick="location.href='buy6.php'">
		</div>
		<div id="crdiv5">
			<img src="<?php echo base_url('images/franela3.jpg'); ?>" class="crtimg">
			<p class="crtcs">$24.99</p>
			<p class="crtcs1">some quick example text to buid on<br>the card title and make up the bulk of<br>the card's content</p>
			<input type="button" name="cart" value="ADD TO CART" id="spbtnn1" onclick="location.href='buy4.php'">
		</div>

		<div id="crdiv6">
			<img src="<?php echo base_url('images/taza3.png'); ?>" class="crtimg">
			<p class="crtcs">$24.99</p>
			<p class="crtcs1">some quick example text to buid on<br>the card title and make up the bulk of<br>the card's content</p>
			<input type="button" name="cart" value="ADD TO CART" id="spbtnn1" onclick="location.href='buy7.php'">
		</div>

		</div>
		<div class="sub1">
		<div id="pa">
		<p id="parr"><strong>View shopping cart</strong></p>
		<p id="parrr">You can see the products that you added to your cart</p>
	</div>
		<form id="form1">
			<div>
			<input type="button" value="SUBMIT" id="b1" onclick="location.href='<?php echo site_url('Homecontroller/buy2open'); ?>'">
			</div>
		</form>
	</div>

<? php include_once('footer2.php'); ?>
<div class="temp4">
	<div class="hmth10" style="background:white;box-shadow: 0px 0px 5px 0px  lightgrey;"><p style="margin-top: 4%; margin-left: 4%">Add to Cart</p>
			<p id="tprr">x</p></div>
			<img src="<?php echo base_url('images/franela2.jpg'); ?>" id="byimg1">
			<div class="byrgt" style="margin-left: 6%;">
				
				<form method="POST" action="<?php echo site_url("Homecontroller/buy3v"); ?>">
				<p id="rttx">Product quantity</p>
				<input type="number" name="qty" style="border: 1px solid lightgrey" id="rttxbx" required>
				<p class="byrp2">Note: Some quick example text<br>to buid on the card title and<br>make up the bulk of the card's<br>content.</p>
				<div id="bybtn">
				<input type="button" name="close" value="Close" id="btnby1" style="background: #6b6b6b" onclick="location.href='<?php echo site_url("Homecontroller/buyopen"); ?>'">
				<input type="submit" name="Add to Cart" value="Add to Cart" id="btnby1" style="background: dodgerblue;">
			</div>
			</form>
			</div>
</div>