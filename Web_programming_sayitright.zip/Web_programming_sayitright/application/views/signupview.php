<? php include_once('header.php'); ?>
<h5 style=" position: absolute; top: 15%; left: 34.7%; color: white; font-family:arial ">Home &rarr; Sign Up</h5>
	<h1 class="hdbta">SIGN UP</h1>
	<div id="abmid">
		<div class="temp1"></div>
		<div class="sgnup">
			<form>
				<h2 id="sp" style="color: grey">Select the type of user</h2>
				<input type="button" name="individual" value="INDIVIDUAL" class="lbt" onclick="location.href='<?php echo site_url('Homecontroller/signup1open'); ?>'">
				<input type="button" name="event" value="EVENT" class="lbt1" onclick="location.href='<?php echo site_url('Homecontroller/signup2open'); ?>'">
				<input type="button" name="business" value="BUSINESS" class="lbt1" onclick="location.href='<?php echo site_url('Homecontroller/signup3open'); ?>'">
			</form>
		</div>
	</div>

<? php include_once('footer.php'); ?>