

<!DOCTYPE html>
<html>
<head>
	<title>add data</title>
	<script type="text/javascript" src="validation.js" ></script>
</head>
<body>
	<p>Enter event details:</p>
<form onsubmit="return example()" method="POST" action="<?php echo site_url("Homecontroller/addv"); ?>" >
			<input type="text" name="conference" placeholder="Conference Name" id="contactfname" ><br>
			<input type="textarea" name="desc" placeholder="Enter Description" id="contactlname"><br>
			<input type="text" name="date" placeholder="Enter Date Eg: 25th aug 2019" id="contactphone"><br>
			<input type="text" name="sede" placeholder="Enter location" id="cntarea" id="contactareat"><br>
			<input type="submit" name="send" value="ADD" >
		</form>
</body>
</html>