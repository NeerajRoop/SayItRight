<? php include_once('headerinside.php'); ?>
<h1 class="hcon">List Of My Conferences</h1>
	<table class="tbl" style="top: 50%; left:10%;">
		<tr class="ctdd">
			<th class="ctd">Conference</th>
			<th class="ctd">Description</th>
			<th class="ctd">Date</th>
			<th class="ctd">Sede</th>
			<th class="ctd">Confirmation</th>
		</tr>
		<?php
		$_SESSION['message'] = "";
		$mysqli= new mysqli('localhost','root','','sayitright1') or die("unable to connect");
		$sess = $_SESSION['email'];
		$sql = "SELECT * FROM confery1 WHERE comfy='$sess'";
		$res= $mysqli->query($sql);
		while ($row = $res->fetch_assoc()){

			?>

		<tr class="ctdd">
		<td class="ctd"><?= $row['conference1'] ?></td>
		<td class="ctd"><?= $row['description1'] ?></td>
		<td class="ctd"><?= $row['date1'] ?></td>
		<td class="ctd"><?= $row['sede1'] ?></td>
		<td class="ctd">confirm</td>
		</tr>

		<?php
	}
	?>

	</table>
	<input type="button" name="delete" value="DELETE" style="position: relative; left: -45%;" id="lgbtn" onclick="location.href='<?php echo site_url('Homecontroller/delete4open'); ?>'">
<? php include_once('footer.php'); ?>