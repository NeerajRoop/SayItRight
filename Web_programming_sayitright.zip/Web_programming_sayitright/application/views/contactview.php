<? php include_once('header.php'); ?>

<h5 style=" position: absolute; top: 15%; left: 34.7%; color: white; font-family:arial ">Home &rarr; Contact Us</h5>
	<h1 class="hdabt">CONTACT US</h1>

	<div id="abmid">
		<?php echo  validation_errors(); ?>
		<form onsubmit="return example()" method="POST" action="<?php echo site_url('Homecontroller/contactv'); ?>">
			<div id="lftcnt">
			<input type="text" name="firstname" placeholder="Enter your name" class="cntx" id="contactfname" ><br>
			<input type="text" name="lastname" placeholder="Enter Last name" class="cntx" id="contactlname">
			<br>
			<input type="text" name="Telephone" placeholder="Telephone" class="cntx" id="contactphone" pattern="\d{3}-\d{3}-\d{4}">
			<br>
			</div>
			<input type="textarea" name="EntertheMessage" placeholder="Enter Message" id="cntarea" id="contactareat" required>
			<input type="submit" name="send" value="SEND MESSAGE" id="cntbtn">
		</form>
	</div>

<? php include_once('footer.php'); ?>