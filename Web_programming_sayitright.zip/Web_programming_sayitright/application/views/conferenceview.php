<? php include_once('headerinside.php'); ?>
<h1 class="hcon">List Of Conferences</h1>
	<table class="tbl" style="top: 50%;left: 10%">
		<tr class="ctdd">
			<th class="ctd">Conference</th>
			<th class="ctd">Description</th>
			<th class="ctd">Date</th>
			<th class="ctd">Sede</th>
			<th class="ctd">Confirmation</th>
		</tr>
		<?php

		$_SESSION['message'] = "";
		$mysqli= new mysqli('localhost','root','','sayitright1') or die("unable to connect");
	
		$sql = "SELECT * FROM confery";
		$res= $mysqli->query($sql);
		$i=0;
		while ($row = $res->fetch_assoc()){

			?>

		<tr class="ctdd">
		<td class="ctd"><?= $row['conference1'] ?></td>
		<td class="ctd"><?= $row['description1'] ?></td>
		<td class="ctd"><?= $row['date1'] ?></td>
		<td class="ctd"><?= $row['sede1'] ?></td>
		<td class="ctd">confirm</td>
		</tr>

		<?php
	}
	?>

	</table>
	<input type="button" name="add" value="ADD" style="position: relative; left: -55.5%; <?= $_SESSION['display'] ?>" id="lgbtn" onclick="location.href='<?php echo site_url('Homecontroller/add2open'); ?>'" >
	<input type="button" name="add1" value="ADD TO YOURS" style="position: relative; left: -54.5%;" id="lgbtn" onclick="location.href='<?php echo site_url('Homecontroller/add3open'); ?>'" >
	<input type="button" name="delete" value="DELETE" style="position: relative; left: -53%; <?= $_SESSION['display'] ?>" id="lgbtn" onclick="location.href='<?php echo site_url('Homecontroller/delete2open'); ?>'">
<? php include_once('footer.php'); ?>