<? php include_once('header.php'); ?>
<h5 style=" position: absolute; top: 15%; left: 36.2%; color: white; font-family:arial ">Home &rarr; Login</h5>
	<h1 class="hdbt">LOGIN</h1>
	<div id="abmid">
		<div class="temp"></div>
		<div class="lgin">
			<?php echo  validation_errors(); ?>
			<form onsubmit="example2()" method="POST" action="<?php echo site_url('Homecontroller/loginv'); ?>">
				<input type="text" name="loginemail" placeholder="Enter Email" class="cntx" id="loginemail"><br>
				<input type="password" name="loginpass" placeholder="Enter password" class="cntx" id="loginpass" ><br>
					<input type="submit" name="send" value="SEND" id="lgbtn">
			</form>
		</div>
	</div>
<? php include_once('footer.php'); ?>