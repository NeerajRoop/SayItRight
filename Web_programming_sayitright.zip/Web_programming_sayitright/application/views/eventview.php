
<? php include_once('headerinside.php'); ?>
<h1 class="hcon" style="margin-left: 5%;">List Of Events</h1>
	
	<table class="tbl" style="top: 50%;left: 10%;">
		<tr class="ctdd">
			<th class="ctd">Conference</th>
			<th class="ctd">Description</th>
			<th class="ctd">Date</th>
			<th class="ctd">Sede</th>
			<th class="ctd">Confirmation</th>
		</tr>
		<?php

		$_SESSION['message'] = "";
		$mysqli= new mysqli('localhost','root','','sayitright1') or die("unable to connect");
	
		$sql = "SELECT * FROM eventadd";
		$res= $mysqli->query($sql);
		while ($row = $res->fetch_assoc()){

			?>

		<tr class="ctdd">
		<td class="ctd"><?= $row['conference'] ?></td>
		<td class="ctd"><?= $row['description'] ?></td>
		<td class="ctd"><?= $row['date'] ?></td>
		<td class="ctd"><?= $row['sede'] ?></td>
		<td class="ctd">confirm</td>
		</tr>

		<?php
	}
	?>

	</table>

	<input type="button" name="add" value="ADD" style="position: relative; left: -55.5%; <?= $_SESSION['display'] ?>" id="lgbtn" onclick="location.href='<?php echo site_url('Homecontroller/addopen'); ?>'" >
	<input type="button" name="add1" value="ADD TO YOURS" style="position: relative; left: -54.5%;" id="lgbtn" onclick="location.href='<?php echo site_url('Homecontroller/add1open'); ?>'" >
	<input type="button" name="delete" value="DELETE" style="position: relative; left: -53%; <?= $_SESSION['display'] ?>" id="lgbtn" onclick="location.href='<?php echo site_url('Homecontroller/deleteopen'); ?>'">
<? php include_once('footer.php'); ?>