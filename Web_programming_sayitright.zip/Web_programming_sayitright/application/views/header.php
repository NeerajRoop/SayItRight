<!doctype html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="sayitright.css">
</head>

<body id="wrapper">
	<div id="home">
	<nav class="nv">
		<div id=nv>

		<img src="<?php echo base_url('images/sayiticon.png'); ?>" class="icn">
		<div class="nvaa">
		<a href="<?php echo site_url('Homecontroller/homeopen'); ?>" class="nva">HOME</a>
		<a href="<?php echo site_url('Homecontroller/aboutopen'); ?>" class="nva">ABOUT US</a>
		<a href="http://neerajroop.uta.cloud/blog/" class="nva">BLOG</a>
		<a href="<?php echo site_url('Homecontroller/buyopen'); ?>" class="nva">BUY FROM US</a>
		<a href="<?php echo site_url('Homecontroller/contactopen'); ?>" class="nva">CONTACT</a>
		<a href="<?php echo site_url('Homecontroller/signupopen'); ?>" class="nva">SIGN UP</a>
		<a href="<?php echo site_url('Homecontroller/loginopen'); ?>" class="nva">LOGIN</a>
	</div>
	</div>
	</nav>
	<img src="<?php echo base_url('images/home-banner.jpg'); ?>" class="bgmg">



