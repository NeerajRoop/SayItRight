
<!DOCTYPE html>
<html>
<head>
	<title>delete</title>
	<script type="text/javascript" src="validation.js"></script>
</head>
<body>
	<p>Enter the name of the event that you want to delete:</p>
	<form onsubmit="return example3()" method="POST" action="<?php  echo site_url('Homecontroller/deletev'); ?>">
		<input type="text" name="deleteform" placeholder="Enter conference name" id="deletetxt"><br>
		<input type="submit" name="submit" value="DELETE" >
	</form>
</body>
</html>