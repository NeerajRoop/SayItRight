<?php
$_SESSION['message'] = "";
		$mysqli= new mysqli('localhost','root','','sayitright1') or die("unable to connect");
		$sess = $_SESSION['email'];
		$sql = "SELECT * FROM eventadd1 WHERE confirm='$sess'";
		$res= $mysqli->query($sql);
		$arr1 = array();
		$i=0;
		while ($row = $res->fetch_assoc()){

			$arr1[$i]=array($row['conference'], $row['description']);
			$i = $i + 1 ;
		}
		$tot = $i;
		while ($i<4) {
			$arr1[$i]=array("None","None");
			$i = $i + 1 ;
		}
		

		$sql1 = "SELECT * FROM confery1 WHERE comfy='$sess'";
		$res1= $mysqli->query($sql1);
		$arr2 = array();
		$j=0;
		while ($row1 = $res1->fetch_assoc()){

			$arr2[$j]=array($row1['conference1'], $row1['description1']);
			$j = $j + 1 ;
		}
		$tot1= $j;
		while ($j<4) {
			$arr2[$j]=array("None","None");
			$j = $j + 1 ;
		}

		$tot3 = $tot + $tot1;
		

?>
<? php include_once('headerinside.php'); ?>
<div class="tpbx">
			<div class="tp" style="background: dodgerblue">
				<i class="fas fa-globe-americas" id="tpic"></i>
				<p id="tpnm">26</p>
				<p id="tptx">activities performed</p>
			</div>
			<div>
				<p class="btm">Total Made</p>
			</div>
		</div>

		<div class="tpbx1">
			<div class="tp" style="background: #11a043">
				<i class="fas fa-users" id="tpic"></i>
				<p id="tpnm"><?= $tot1 ?></p>
				<p id="tptx" style="left:40%">activities performed</p>
			</div>
			<div>
				<p class="btm">Conferences</p>
			</div>
		</div>

		<div class="tpbx2">
			<div class="tp" style="background: #ffbb00">
				<i class="fas fa-star" id="tpic"></i>
				<p id="tpnm"><?= $tot ?></p>
				<p id="tptx">activities performed</p>
			</div>
			<div>
				<p class="btm" style="left: 71%">Events</p>
			</div>
		</div>

		<div class="tpbx3">
			<div class="tp" style="background: #6b6b6b">
				<i class="fas fa-trophy" id="tpic"></i>
				<p id="tpnm"><?= $tot3 ?></p>
				<p id="tptx">activities to carry out</p>
			</div>
			<div>
				<p class="btm" style="left: 67%">Activities</p>
			</div>
		</div>

	
		<div class="hmtb" style="background: dodgerblue;">


			<div class="hmth" style="background: #2c8ccc;box-shadow: 0px 0px 5px 0px  #2c8ccc;">Event 1</div>
			<div class="ggg">
				<p class="hmtp"><?= $arr1[0][0] ?></p>
				<p class="hmtp2"><?= $arr1[0][1] ?></p>
			</div>

	</div>

	<div class="hmtb2" style="background: grey;">

			<div class="hmth" style="background: #6b6b6b;box-shadow: 0px 0px 5px 0px  #6b6b6b;">Event 2</div>
			<div class="ggg">
				<p class="hmtp"><?= $arr1[1][0] ?></p>
				<p class="hmtp2"><?= $arr1[1][1] ?></p>
			</div>

	</div>
	<div class="hmtb3" style="background: #11a043;">

			<div class="hmth" style="background: #108c3c;box-shadow: 0px 0px 5px 0px  #108c3c;">Event 3</div>
			<div class="ggg">
				<p class="hmtp"><?= $arr1[2][0] ?></p>
				<p class="hmtp2"><?= $arr1[2][1] ?></p>
			</div>

	</div>
	<div class="hmtb4" style="background: #d64646;">

			<div class="hmth" style="background: #ce4040;box-shadow: 0px 0px 5px 0px  #ce4040;">Event 4</div>
			<div class="ggg">
				<p class="hmtp"><?= $arr1[3][0] ?></p>
				<p class="hmtp2"><?= $arr1[3][1] ?></p>
			</div>

	</div>
	<div class="hmtb5" style="background: #ffbb00;">

			<div class="hmth" style="background: #efaf00;box-shadow: 0px 0px 5px 0px  #efaf00;">Conference 1</div>
			<div class="ggg">
				<p class="hmtp"><?= $arr2[0][0] ?></p>
				<p class="hmtp2"><?= $arr2[0][1] ?></p>
			</div>

	</div>
	<div class="hmtb6" style="background: #009ec1;">

			<div class="hmth" style="background: #0091b2;box-shadow: 0px 0px 5px 0px  #0091b2;">Conference 2</div>
			<div class="ggg">
				<p class="hmtp"><?= $arr2[1][0] ?></p>
				<p class="hmtp2"><?= $arr2[1][1] ?></p>
			</div>

	</div>
	<div class="hmtb7" style="background:white; color: black">

			<div class="hmth"style="background: #e8eaea;box-shadow: 0px 0px 5px 0px  lightgrey;">Conference 3</div>
			<div class="ggg">
				<p class="hmtp"><?= $arr2[2][0] ?></p>
				<p class="hmtp2"><?= $arr2[2][1] ?></p>
			</div>

	</div>
	<div class="hmtb8" style="background: #313233;">

			<div class="hmth" style="background: #2a2b2b;box-shadow: 0px 0px 5px 0px  #2a2b2b;">Conference 4</div>
			<div class="ggg">
				<p class="hmtp"><?= $arr2[3][0] ?></p>
				<p class="hmtp2"><?= $arr2[3][1] ?></p>
			</div>

	</div>

<? php include_once('footer3.php'); ?>