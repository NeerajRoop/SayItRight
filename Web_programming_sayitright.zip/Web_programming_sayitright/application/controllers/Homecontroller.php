<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Homecontroller extends CI_Controller{
	public function index(){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('homeview');
		$this->load->view('footer');
	}

	public function aboutopen(){
	$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('aboutview');
		$this->load->view('footer');
}
	public function homeopen(){
	$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('homeview');
		$this->load->view('footer');
}
	public function buyopen(){
	$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buyview');
		$this->load->view('footer2');
}
	public function buy1open(){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buy1view');
		$this->load->view('footer2');
}
	public function buy2open(){
	$this->load->view('header2');
		$this->load->view('styling');
		$this->load->view('buy2view');
		$this->load->view('footer3');
}
	public function buy3open(){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buy3view');
		$this->load->view('footer2');
}

	public function buy4open(){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buy4view');
		$this->load->view('footer2');
}
	public function buy5open(){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buy5view');
		$this->load->view('footer2');
}
	public function buy6open(){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buy6view');
		$this->load->view('footer2');
}
	public function buy7open(){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buy7view');
		$this->load->view('footer2');
}
	public function contactopen(){
		
	$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('contactview');
		$this->load->view('footer');
		$this->load->library('form_validation');
		
}
	public function signupopen(){
	$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('signupview');
		$this->load->view('footer');
}
	public function signup1open(){
	$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('signup1view');
		$this->load->view('footer3');
}
	public function signup2open(){
	$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('signup2view');
		$this->load->view('footer3');
}
	public function signup3open(){
	$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('signup3view');
		$this->load->view('footer3');
}
	public function loginopen(){
	$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('loginview');
		$this->load->view('footer');
}
	public function homeinsideopen(){
	$this->load->view('headerinside');
		$this->load->view('styling');
		$this->load->view('home1view');
		$this->load->view('footer3');
}
	public function conferenceopen(){
	$this->load->view('headerinside');
		$this->load->view('styling');
		$this->load->view('conferenceview');
		$this->load->view('footer');
}
	public function eventopen(){
	$this->load->view('headerinside');
		$this->load->view('styling');
		$this->load->view('eventview');
		$this->load->view('footer');
}
	public function myconferenceopen(){
	$this->load->view('headerinside');
		$this->load->view('styling');
		$this->load->view('myconview');
		$this->load->view('footer');
}
	public function myeventopen(){
	$this->load->view('headerinside');
		$this->load->view('styling');
		$this->load->view('myeventview');
		$this->load->view('footer');
}
	public function settingsopen(){
	$this->load->view('headerinside');
		$this->load->view('styling');
		$this->load->view('settingsview');
		$this->load->view('footer');
}
	public function addopen(){
	$this->load->view('add');

}
	public function add1open(){
	$this->load->view('add1');

}
	public function add2open(){
	$this->load->view('add2');

}
	public function add3open(){
	$this->load->view('add3');

}
	public function deleteopen(){
	$this->load->view('delete');

}
	public function delete4open(){
	$this->load->view('delete4');

}
public function delete2open(){
	$this->load->view('delete2');

}
public function delete3open(){
	$this->load->view('delete3');

}

public function contactv(){
	$this->load->library('form_validation');
	$this->form_validation->set_rules('firstname','First name', 'required');
	$this->form_validation->set_rules('lastname','Last name', 'required');
	$this->form_validation->set_rules('Telephone','Phone number', 'required');
	$this->form_validation->set_rules('EntertheMessage','Message', 'required');
	if($this->form_validation->run()==FALSE){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('contactview');
		$this->load->view('footer');
	}
	else{
		$this->load->model("contactmodel");
		$data = array(
			"fname"=>$this->input->post("firstname"),
			"lname"=>$this->input->post("lastname"),
			"phone"=>$this->input->post("Telephone"),
			"message"=>$this->input->post("EntertheMessage")
		);
		if($this->contactmodel->insert($data)==TRUE){
			$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('homeview');
		$this->load->view('footer');
		}
		else{
			echo "Cannot insert in database";
		}
	}
}
public function signup1v(){
	$this->load->library('form_validation');
	$this->form_validation->set_rules('nme','First name', 'required');
	$this->form_validation->set_rules('lnme','Last name', 'required');
	$this->form_validation->set_rules('work','Work', 'required');
	$this->form_validation->set_rules('school','School', 'required');
	$this->form_validation->set_rules('email','Email', 'required');
	$this->form_validation->set_rules('pwd','Password', 'required');
	if($this->form_validation->run()==FALSE){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('signup1view');
		$this->load->view('footer3');	
	}
	else{

		$this->load->model("signup1model");
		$data=array(
			"fname"=>$this->input->post("nme"),
			"lname"=>$this->input->post("lnme"),
			"work" => $this->input->post("work"),
			"school"=>$this->input->post("school"),
			"email"=>$this->input->post("email"),
			"pass"=>$this->input->post("pwd")
		);

		$data1 = array(
			"type"=>"individual",
			"email"=>$this->input->post("email"),
			"pass"=>$this->input->post("pwd")

		);

		if($this->signup1model->insert1($data)==TRUE and $this->signup1model->insert2($data1)==TRUE){

		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('loginview');
		$this->load->view('footer');
	}
	else{
		echo "data cannot be inserted";
	}
	}
}

public function signup2v(){
	$this->load->library('form_validation');
	$this->form_validation->set_rules('nme','First name', 'required');
	$this->form_validation->set_rules('lnme','Last name', 'required');
	$this->form_validation->set_rules('email','Email', 'required');
	$this->form_validation->set_rules('pwd','Password', 'required');
	if($this->form_validation->run()==FALSE){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('signup2view');
		$this->load->view('footer3');	
	}
	else{
		$this->load->model("signup2model");
		$data=array(
			"fname"=>$this->input->post("nme"),
			"lname"=>$this->input->post("lnme"),
			"email"=>$this->input->post("email"),
			"pass"=>$this->input->post("pwd")
		);

		$data1 = array(
			"type"=>"events",
			"email"=>$this->input->post("email"),
			"pass"=>$this->input->post("pwd")

		);

		if($this->signup2model->insert1($data)==TRUE and $this->signup2model->insert2($data1)==TRUE){

		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('loginview');
		$this->load->view('footer');
	}
	else{
		echo "data cannot be inserted";
	}
	}
}

public function signup3v(){
	$this->load->library('form_validation');
	$this->form_validation->set_rules('lnme','Last name', 'required');
	$this->form_validation->set_rules('email','Email', 'required');
	$this->form_validation->set_rules('pwd','Password', 'required');
	if($this->form_validation->run()==FALSE){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('signup3view');
		$this->load->view('footer3');	
	}
	else{
		$this->load->model("signup3model");
		$data=array(
			"type"=>$this->input->post("bsns"),
			"lname"=>$this->input->post("lnme"),
			"email"=>$this->input->post("email"),
			"pass"=>$this->input->post("pwd")
		);

		$data1 = array(
			"type"=>"business",
			"email"=>$this->input->post("email"),
			"pass"=>$this->input->post("pwd")

		);

		if($this->signup3model->insert1($data)==TRUE and $this->signup3model->insert2($data1)==TRUE){

		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('loginview');
		$this->load->view('footer');
	}
	else{
		echo "data cannot be inserted";
	}
	}
}

public function loginv(){
	$this->load->library('form_validation');
	$this->form_validation->set_rules('loginemail','Email', 'required');
	$this->form_validation->set_rules('loginpass','Password', 'required');
	if($this->form_validation->run()==FALSE){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('loginview');
		$this->load->view('footer');	
	}
	else{
		$a=$this->input->post('loginemail');
		$b=$this->input->post('loginpass');
		$count=0;
		$this->load->model("loginmodel");
		$res = $this->loginmodel->get();
		foreach ($res->result() as $row ) {
			if($row->email==$a and $row->pass==$b){
				$count=1;
				$type = $row->type;
				}
			}
			if($count==1 and $type=="individual"){
				$res1 = $this->loginmodel->getindividual();
				foreach ($res1->result() as $row1) {
					if($row1->email==$a and $row1->pass==$b){
						$this->load->library("session");
						$this->session->set_userdata('fname',$row1->fname);
						$this->session->set_userdata('lname',$row1->lname);
						$this->session->set_userdata('work',$row1->work);
						$this->session->set_userdata('school',$row1->school);
						$this->session->set_userdata('email',$row1->email);
						$this->session->set_userdata('pass',$row1->pass);
						$this->session->set_userdata('display',"display:none");

				}
			}

				$this->load->view('headerinside');
				$this->load->view('styling');
				$this->load->view('home1view');
				$this->load->view('footer3');
			}
			elseif($count==1 and $type=="events"){
				$res1 = $this->loginmodel->getevents();
				foreach ($res1->result() as $row1) {
					if($row1->email==$a and $row1->pass==$b){
						$this->load->library("session");
						$this->session->set_userdata('fname',$row1->fname);
						$this->session->set_userdata('lname',$row1->lname);
						$this->session->set_userdata('work',"");
						$this->session->set_userdata('school',"");
						$this->session->set_userdata('email',$row1->email);
						$this->session->set_userdata('pass',$row1->pass);
						$this->session->set_userdata('display',"");

				}
			}

				$this->load->view('headerinside');
				$this->load->view('styling');
				$this->load->view('home1view');
				$this->load->view('footer3');
			}
			elseif($count==1 and $type=="business"){
				$res1 = $this->loginmodel->getbusiness();
				foreach ($res1->result() as $row1) {
					if($row1->email==$a and $row1->pass==$b){
						$this->load->library("session");
						$this->session->set_userdata('fname',"");
						$this->session->set_userdata('lname',$row1->lname);
						$this->session->set_userdata('work',"");
						$this->session->set_userdata('school',"");
						$this->session->set_userdata('email',$row1->email);
						$this->session->set_userdata('pass',$row1->pass);
						$this->session->set_userdata('display',"");

				}
			}

				$this->load->view('headerinside');
				$this->load->view('styling');
				$this->load->view('home1view');
				$this->load->view('footer3');
			}
			elseif($count==0){
				echo "Invalid email or password";
			}
			
		}


		
	}

public function buy2v(){
	$this->load->library('form_validation');
	$this->form_validation->set_rules('eml','Email', 'required');
	$this->form_validation->set_rules('nme','First name', 'required');
	$this->form_validation->set_rules('lnme','Last name', 'required');
	$this->form_validation->set_rules('work','Address', 'required');
	$this->form_validation->set_rules('school','Apt', 'required');
	$this->form_validation->set_rules('email','City', 'required');
	$this->form_validation->set_rules('lnmess','Postal', 'required');
	
	if($this->form_validation->run()==FALSE){
		$this->load->view('header2');
		$this->load->view('styling');
		$this->load->view('buy2view');
		$this->load->view('footer3');
	}
	else{
			$this->load->model("buy2model");
		$data=array(
			"email"=>$this->input->post("eml"),
			"fname"=>$this->input->post("nme"),
			"lname"=>$this->input->post("lnme"),
			"address" => $this->input->post("work"),
			"apt"=>$this->input->post("school"),
			"city"=>$this->input->post("email"),
			"language"=>$this->input->post("lang"),
			"postal"=>$this->input->post("lnmess")
		);

		

		if($this->buy2model->insert($data)==TRUE and $this->buy2model->delete()==TRUE){

		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buyview');
		$this->load->view('footer2');
	}
	else{
		echo "data cannot be inserted";
	}
		
	}
}

public function addv(){
	$this->load->model("addmodel");
	$data=array(
		"conference"=>$this->input->post("conference"),
		"description"=>$this->input->post("desc"),
		"date"=>$this->input->post("date"),
		"sede"=>$this->input->post("sede"),
		"confirm"=>"confirm"
	);
	if($this->addmodel->insert($data)==TRUE){
		$this->load->view('headerinside');
			$this->load->view('styling');
			$this->load->view('home1view');
			$this->load->view('footer3');

	}
	else{
		echo "Data cannot be added";
	}
}
public function add2v(){
	$this->load->model("add2model");
	$data=array(
		"conference1"=>$this->input->post("conference"),
		"description1"=>$this->input->post("desc"),
		"date1"=>$this->input->post("date"),
		"sede1"=>$this->input->post("sede"),
		"comfy"=>"confirm"
	);
	if($this->add2model->insert($data)==TRUE){
		$this->load->view('headerinside');
			$this->load->view('styling');
			$this->load->view('home1view');
			$this->load->view('footer3');

	}
	else{
		echo "Data cannot be added";
	}
}

public function deletev(){
	$this->load->model("deletemodel");
	$data = $this->input->post('deleteform');
	if($this->deletemodel->delete($data)==TRUE and $this->deletemodel->delete1($data)==TRUE){
		$this->load->view('headerinside');
		$this->load->view('styling');
		$this->load->view('home1view');
		$this->load->view('footer3');
	}
	else{
		echo "Data cannot be deleted";
	}
}
public function delete3v(){
	$this->load->model("delete3model");
	$data = $this->input->post('deleteform');
	if($this->delete3model->delete1($data)==TRUE){
		$this->load->view('headerinside');
		$this->load->view('styling');
		$this->load->view('home1view');
		$this->load->view('footer3');
	}
	else{
		echo "Data cannot be deleted";
	}
}

public function delete2v(){
	$this->load->model("delete2model");
	$data = $this->input->post('deleteform');
	if($this->delete2model->delete($data)==TRUE and $this->delete2model->delete1($data)==TRUE){
		$this->load->view('headerinside');
		$this->load->view('styling');
		$this->load->view('home1view');
		$this->load->view('footer3');
	}
	else{
		echo "Data cannot be deleted";
	}
}

public function delete4v(){
	$this->load->model("delete2model");
	$data = $this->input->post('deleteform');
	if($this->delete2model->delete1($data)==TRUE){
		$this->load->view('headerinside');
		$this->load->view('styling');
		$this->load->view('home1view');
		$this->load->view('footer3');
	}
	else{
		echo "Data cannot be deleted";
	}
}
	
public function buy1v(){
	$this->load->model("buy1model");
	$a = $this->input->post("qty");
	$b = $a*24.99;
	$data=array(
		"ID"=>"franela1.jpg",
		"units"=> $this->input->post("qty"),
		"name" =>"White shirt",
		"price"=>$b
	);
	if($this->buy1model->insert($data)==TRUE){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buyview');
		$this->load->view('footer2');
	}
	else{
		echo "Cannot add item";
	}
}

public function buy3v(){
	$this->load->model("buy1model");
	$a = $this->input->post("qty");
	$b = $a*24.99;
	$data=array(
		"ID"=>"franela2.jpg",
		"units"=> $this->input->post("qty"),
		"name" =>"Blue shirt",
		"price"=>$b
	);
	if($this->buy1model->insert($data)==TRUE){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buyview');
		$this->load->view('footer2');
	}
	else{
		echo "Cannot add item";
	}
}

public function buy4v(){
	$this->load->model("buy1model");
	$a = $this->input->post("qty");
	$b = $a*24.99;
	$data=array(
		"ID"=>"franela3.jpg",
		"units"=> $this->input->post("qty"),
		"name" =>"Red shirt",
		"price"=>$b
	);
	if($this->buy1model->insert($data)==TRUE){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buyview');
		$this->load->view('footer2');
	}
	else{
		echo "Cannot add item";
	}
}

public function buy5v(){
	$this->load->model("buy1model");
	$a = $this->input->post("qty");
	$b = $a*24.99;
	$data=array(
		"ID"=>"taza1.png",
		"units"=> $this->input->post("qty"),
		"name" =>"cup",
		"price"=>$b
	);
	if($this->buy1model->insert($data)==TRUE){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buyview');
		$this->load->view('footer2');
	}
	else{
		echo "Cannot add item";
	}
}
public function buy6v(){
	$this->load->model("buy1model");
	$a = $this->input->post("qty");
	$b = $a*24.99;
	$data=array(
		"ID"=>"taza2.png",
		"units"=> $this->input->post("qty"),
		"name" =>"cup",
		"price"=>$b
	);
	if($this->buy1model->insert($data)==TRUE){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buyview');
		$this->load->view('footer2');
	}
	else{
		echo "Cannot add item";
	}
}

public function buy7v(){
	$this->load->model("buy1model");
	$a = $this->input->post("qty");
	$b = $a*24.99;
	$data=array(
		"ID"=>"taza3.png",
		"units"=> $this->input->post("qty"),
		"name" =>"cup",
		"price"=>$b
	);
	if($this->buy1model->insert($data)==TRUE){
		$this->load->view('header');
		$this->load->view('styling');
		$this->load->view('buyview');
		$this->load->view('footer2');
	}
	else{
		echo "Cannot add item";
	}
}


	


}


?>