<?php
class addmodel extends CI_Model{
	function insert($data){
		return $this->db->insert("eventadd",$data);
	}
}



?>