<?php

class contactmodel extends CI_Model{
	public function insert($data){
		return $this->db->insert("contact",$data);
	}
}
?>