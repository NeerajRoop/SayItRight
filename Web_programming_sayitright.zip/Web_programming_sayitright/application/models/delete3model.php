<?php
class delete3model extends CI_Model{
	public function delete1($data){
		return $this->db->delete('eventadd1',array('conference'=>$data));
	}
}

?>