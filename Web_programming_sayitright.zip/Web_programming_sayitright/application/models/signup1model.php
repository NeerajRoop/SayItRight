<?php

class signup1model extends CI_Model{
	public function insert1($data){
		return $this->db->insert("individual",$data);
	}
	public function insert2($data1){
		return $this->db->insert("logindetails",$data1);
	}
}
?>