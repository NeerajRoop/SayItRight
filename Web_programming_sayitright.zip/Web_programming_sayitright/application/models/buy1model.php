<?php
class buy1model extends CI_Model{
	public function insert($data){
		return $this->db->insert("cart",$data);
	}
}


?>