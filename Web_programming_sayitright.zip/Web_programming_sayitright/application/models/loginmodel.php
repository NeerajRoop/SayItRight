<?php

class loginmodel extends CI_Model{
	public function get(){
		return $this->db->get("logindetails");
	}
	public function getindividual(){
		return $this->db->get("individual");
	}
	public function getevents(){
		return $this->db->get("events");
	}
	public function getbusiness(){
		return $this->db->get("business");
	}
}
?>