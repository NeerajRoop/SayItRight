<?php
class add2model extends CI_Model{
	function insert($data){
		return $this->db->insert("confery",$data);
	}
}



?>