<?php

class buy2model extends CI_Model{
	public function insert($data){
		return $this->db->insert("buy",$data);
	}
	public function delete(){
		return $this->db->empty_table("cart");
	}
}
?>