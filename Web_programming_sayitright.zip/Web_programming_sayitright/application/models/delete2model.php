<?php
class delete2model extends CI_Model{
	public function delete($data){
		return $this->db->delete('confery',array('conference1'=>$data));
	}
	public function delete1($data1){
		return $this->db->delete('confery1',array('conference1'=>$data1));
	}
}

?>