<?php
class deletemodel extends CI_Model{
	public function delete($data){
		return $this->db->delete('eventadd',array('conference'=>$data));
	}
	public function delete1($data1){
		return $this->db->delete('eventadd1',array('conference'=>$data1));
	}
}

?>